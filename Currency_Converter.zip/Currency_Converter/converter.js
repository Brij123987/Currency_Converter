// This is API link
const api="https://api.exchangerate-api.com/v4/latest/USD";

// for selecting different controls

var search = document.querySelector(".searchBox");
var fromcurrency = document.querySelector(".from");
var tocurrency = document.querySelector(".to");
var convert = document.querySelector(".convert");
var finalValue = document.querySelector(".finalValue");
var finalAmount = document.getElementById("finalAmount");

var resultFrom;
var resultTo;
var searchValue;

// Event when currency is changed
fromcurrency.addEventListener('change', (event) => {
    resultFrom =  `${event.target.value}`; //From:INR
});

// Event when currency is changed

tocurrency.addEventListener('change', (event) => {
    resultTo = `${event.target.value}`; //To:USD
});

search.addEventListener('input', updateValue);

// Function for updating value
function updateValue(e) {
    searchValue = e.target.value;
}

// When user clicks, it calls function getresults
convert.addEventListener("click", getresults);

// function getresults
function getresults(){
    fetch(`https://api.exchangerate-api.com/v4/latest/${resultFrom}`)
    .then(currenc => {
        return currenc.json();
    }). then(displayResults);
}

// display results after conversion
function displayResults(currency) {
    let toRate = currency.rates[resultTo];

    finalValue.innerHTML = 
    (toRate * searchValue).toFixed(2);
    // document.write( (toRate * searchValue) .toFixed(2));
    finalAmount.style.display = "block";
}

// When user click on reset button
 function clearVal(){
    window.location.reload();
    document.getElementsByClassName("finalValue").innerHTML = "";
 }

